(time go run hw3-chain.go books/huckleberryFinn.txt chain-results/huckleberryFinn) > chain-results/huckleberryFinn.time 2>&1 && \
(time go run hw3-chain.go books/tomSawyer.txt chain-results/tomSawyer) > chain-results/tomSawyer.time 2>&1 && \
(time go run hw3-chain.go books/innocentAdventuress.txt chain-results/innocentAdventuress) > chain-results/innocentAdventuress.time 2>&1 && \
(time go run hw3-chain.go books/muchAdoAboutNothing.txt chain-results/muchAdoAboutNothing) > chain-results/muchAdoAboutNothing.time 2>&1 && \
(time go run hw3-chain.go books/prodigalVillage.txt chain-results/prodigalVillage) > chain-results/prodigalVillage.time 2>&1 && \
(time go run hw3-quad.go books/huckleberryFinn.txt quad-results/huckleberryFinn) > quad-results/huckleberryFinn.time 2>&1 && \
(time go run hw3-quad.go books/tomSawyer.txt quad-results/tomSawyer) > quad-results/tomSawyer.time 2>&1 && \
(time go run hw3-quad.go books/innocentAdventuress.txt quad-results/innocentAdventuress) > quad-results/innocentAdventuress.time 2>&1 && \
(time go run hw3-quad.go books/muchAdoAboutNothing.txt quad-results/muchAdoAboutNothing) > quad-results/muchAdoAboutNothing.time 2>&1 && \
(time go run hw3-quad.go books/prodigalVillage.txt quad-results/prodigalVillage) > quad-results/prodigalVillage.time 2>&1 && \
(time go run hw3-dbl.go books/huckleberryFinn.txt dbl-results/huckleberryFinn) > dbl-results/huckleberryFinn.time 2>&1 && \
(time go run hw3-dbl.go books/tomSawyer.txt dbl-results/tomSawyer) > dbl-results/tomSawyer.time 2>&1 && \
(time go run hw3-dbl.go books/innocentAdventuress.txt dbl-results/innocentAdventuress) > dbl-results/innocentAdventuress.time 2>&1 && \
(time go run hw3-dbl.go books/muchAdoAboutNothing.txt dbl-results/muchAdoAboutNothing) > dbl-results/muchAdoAboutNothing.time 2>&1 && \
(time go run hw3-dbl.go books/prodigalVillage.txt dbl-results/prodigalVillage) > dbl-results/prodigalVillage.time 2>&1