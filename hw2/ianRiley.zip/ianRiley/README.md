To execute the program, simply run:
  $> . run_hw2.sh
The results for each data structure will be added to its respective results folder.

To run a custom book, use:
  For BST:
  $> time go run hw2.go <book-path> <output-prefix>
  For AVL:
  $> time go run hw2-avl.go <book-path> <output-prefix>
